class StaticPagesController < ApplicationController
  def team
  end
  def contact
  end
end
