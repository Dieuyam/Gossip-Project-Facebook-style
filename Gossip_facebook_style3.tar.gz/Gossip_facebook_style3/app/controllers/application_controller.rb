class ApplicationController < ActionController::Base
  include SessionsHelper
  include LikesHelper
end
